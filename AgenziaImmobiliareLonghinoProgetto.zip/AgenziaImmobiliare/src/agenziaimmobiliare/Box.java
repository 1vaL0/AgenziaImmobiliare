    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenziaimmobiliare;

public class Box extends Immobile {
    int postiAuto;

    public Box(String codice, String indirizzo, String citta, int superficie, double prezzo, int postiAuto) {
        super(codice, indirizzo, citta, superficie, prezzo);
        this.postiAuto = postiAuto;
    }

    @Override
    public String toString() {
        return "Box: " + super.toString() + ", Posti auto: " + postiAuto;
    }
}

