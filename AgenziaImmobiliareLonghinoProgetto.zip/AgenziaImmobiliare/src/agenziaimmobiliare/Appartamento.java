/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenziaimmobiliare;

public class Appartamento extends Immobile {
    int numeroVani;

    public Appartamento(String codice, String indirizzo, String citta, int superficie, double prezzo, int numeroVani) {
        super(codice, indirizzo, citta, superficie, prezzo);
        this.numeroVani = numeroVani;
    }

    @Override
    public String toString() {
        return "Appartamento: " + super.toString() + ", Vani: " + numeroVani;
    }
}
