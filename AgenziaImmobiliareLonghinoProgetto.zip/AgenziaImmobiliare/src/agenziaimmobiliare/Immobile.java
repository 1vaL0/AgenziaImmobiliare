/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenziaimmobiliare;

public class Immobile {
    String codice;
    String indirizzo;
    String citta;
    int superficie;
    double prezzo;

    public Immobile(String codice, String indirizzo, String citta, int superficie, double prezzo) {
        this.codice = codice;
        this.indirizzo = indirizzo;
        this.citta = citta;
        this.superficie = superficie;
        this.prezzo = prezzo;
    }

    @Override
    public String toString() {
        return codice + " - " + indirizzo + ", " + citta + " - " + superficie + " mq - € " + prezzo;
    }
}
