/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package agenziaimmobiliare;

public class AgenziaImmobiliare {
    public static void main(String[] args) {
        Agenzia agenzia = new Agenzia("Immobiliare Semplice");
        

//        agenzia.aggiungiImmobile(new Appartamento("A001", "Via Roma 1", "Roma", 80, 120000, 3));
//        agenzia.aggiungiImmobile(new Villa("V001", "Via Lago 5", "Milano", 200, 350000, 150));
//        agenzia.aggiungiImmobile(new Box("B001", "Via Garage 3", "Napoli", 30, 40000, 2));


        new AgenziaGUI().setVisible(true);
    }
}

