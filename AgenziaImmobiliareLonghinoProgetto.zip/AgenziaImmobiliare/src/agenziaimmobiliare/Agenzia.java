/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenziaimmobiliare;

import java.util.ArrayList;

public class Agenzia {
    String nome;
    ArrayList<Immobile> immobili;

    public Agenzia(String nome) {
        this.nome = nome;
        this.immobili = new ArrayList<>();
    }

    public void aggiungiImmobile(Immobile immobile) {
        immobili.add(immobile);
    }

    public void stampaImmobili() {
        System.out.println("Immobili di " + nome + ":");
        for (Immobile i : immobili) {
            System.out.println(i);
        }
    }
}
