/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenziaimmobiliare;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AgenziaGUI extends JFrame {

    private Agenzia agenzia;

    private JTextField txtCodice, txtIndirizzo, txtCitta, txtSuperficie, txtPrezzo;
    private JTextArea areaOutput;

    public AgenziaGUI() {
        agenzia = new Agenzia("Immobiliare Semplice");

        setTitle("Agenzia Immobiliare - Semplice");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5, 2));

        inputPanel.add(new JLabel("Codice:"));
        txtCodice = new JTextField();
        inputPanel.add(txtCodice);

        inputPanel.add(new JLabel("Indirizzo:"));
        txtIndirizzo = new JTextField();
        inputPanel.add(txtIndirizzo);

        inputPanel.add(new JLabel("Città:"));
        txtCitta = new JTextField();
        inputPanel.add(txtCitta);

        inputPanel.add(new JLabel("Superficie:"));
        txtSuperficie = new JTextField();
        inputPanel.add(txtSuperficie);

        inputPanel.add(new JLabel("Prezzo:"));
        txtPrezzo = new JTextField();
        inputPanel.add(txtPrezzo);

        add(inputPanel, BorderLayout.NORTH);

        areaOutput = new JTextArea();
        areaOutput.setEditable(false);
        add(new JScrollPane(areaOutput), BorderLayout.CENTER);

        JButton btnAggiungi = new JButton("Aggiungi Immobile");
        add(btnAggiungi, BorderLayout.SOUTH);

        btnAggiungi.addActionListener(e -> {
            try {
                String codice = txtCodice.getText().trim();
                String indirizzo = txtIndirizzo.getText().trim();
                String citta = txtCitta.getText().trim();
                int superficie = Integer.parseInt(txtSuperficie.getText().trim());
                double prezzo = Double.parseDouble(txtPrezzo.getText().trim());

                
                Appartamento app = new Appartamento(codice, indirizzo, citta, superficie, prezzo, 0);
                agenzia.aggiungiImmobile(app);

                aggiornaOutput();
                pulisciCampi();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Inserisci numeri validi per superficie e prezzo.");
            }
        });
    }

    private void aggiornaOutput() {
        areaOutput.setText("Immobili registrati:\n");
        for (Immobile i : agenzia.immobili) {
            areaOutput.append(i.toString() + "\n");
        }
    }

    private void pulisciCampi() {
        txtCodice.setText("");
        txtIndirizzo.setText("");
        txtCitta.setText("");
        txtSuperficie.setText("");
        txtPrezzo.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AgenziaGUI().setVisible(true));
    }
}
