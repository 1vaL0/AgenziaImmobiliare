/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenziaimmobiliare;

public class Villa extends Immobile {
    int metriQuadriGiardino;

    public Villa(String codice, String indirizzo, String citta, int superficie, double prezzo, int metriQuadriGiardino) {
        super(codice, indirizzo, citta, superficie, prezzo);
        this.metriQuadriGiardino = metriQuadriGiardino;
    }

    @Override
    public String toString() {
        return "Villa: " + super.toString() + ", Giardino: " + metriQuadriGiardino + " mq";
    }
}
